﻿DO NOT modify the template files in this folder. 
If you want to customize the templates, 
please copy this template folder to the root folder of your project.

请不要直接修改此目录的模板文件。如果你需要个性化模板，请复制template目录到你的项目的根目录，再作修改！

变量说明:

Component.template
-------------
{packageName} UI模块名
{componentName} UI组件父类名
{className} UI组件类名
{uiPkgName} UI资源包名
{uiResName} UI资源名
{uiPath} UI资源路径


Binder.template
———————————
{className}  UI模块名+"Binder"
{packageName} UI模块名